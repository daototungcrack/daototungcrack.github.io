Copy cả folder NTFS Drive Protection sang phân vùng USB-DATA hay HDD-DATA
Xem cách sử dụng tại: https://anh-dv.com/thu-thuat-phan-mem/bao-ve-usb-khoi-virus-chong-ghi-xoa-du-lieu